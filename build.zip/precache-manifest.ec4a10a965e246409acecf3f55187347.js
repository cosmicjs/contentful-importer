self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "769944230b57163f1bd954e894b5724e",
    "url": "/index.html"
  },
  {
    "revision": "af13c5ffce1518b97a68",
    "url": "/static/css/main.3c9ca9a3.chunk.css"
  },
  {
    "revision": "fb9cd5a862cb0865e0da",
    "url": "/static/js/2.d98cb554.chunk.js"
  },
  {
    "revision": "09f875db4a61c220d38d170c67d9427f",
    "url": "/static/js/2.d98cb554.chunk.js.LICENSE"
  },
  {
    "revision": "af13c5ffce1518b97a68",
    "url": "/static/js/main.c4a9db92.chunk.js"
  },
  {
    "revision": "42a8b147aa10dbde66ec",
    "url": "/static/js/runtime-main.9f7c15aa.js"
  },
  {
    "revision": "430d32a1109548663318848501bc732a",
    "url": "/static/media/cosmic-logo.430d32a1.svg"
  }
]);